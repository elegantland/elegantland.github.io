module.exports = {
    onLoad() {
        console.log('MessageBlocker preload loaded');
    },
    onUnload() {
        console.log('MessageBlocker preload unloaded');
    }
};